import logo from './logo.svg';
import './App.css';
import Task from './Components/table';

function App() {
  return (
    <div>
      <Task />
    </div>
  );
}

export default App;
